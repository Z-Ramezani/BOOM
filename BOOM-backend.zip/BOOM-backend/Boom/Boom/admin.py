from django.contrib import admin
from .models import *
# Register your models here.

admin.site.register(Artist)
admin.site.register(Customer)
admin.site.register(Expert)
admin.site.register(Artwork_advertisement)
admin.site.register(User)
admin.site.register(Expert_comment)#change2
admin.site.register(Sample_artwork)#change2