from django.urls import path
from Boom.views import user_views as vi
from Boom.views import ad_views as adv



urlpatterns = [

     path ('register' , vi.RegisterArtistAPI.as_view()),
     path('register/expert' , vi.RegisterExpertAPI.as_view()),
     path('register/customer' , vi.RegisterCustomerAPI.as_view()),
     path('login' , vi.LoginAPI.as_view()),
     # path('Buyticket',vi.BuyTicket ),
     # path('<str:ArtistID>/create_advertisement' , adv.create_advertisement),
     # path('edit_advertisement/<str:pk>' , adv.edit_advertisement),
     # path('delete_advertisement/<str:pk>' , adv.delete_advertisement),

]
